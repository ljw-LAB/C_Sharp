﻿
/* ================= 예제 4.2: Book 타입 정의 및 사용 ================= */

using System;

class Book
{
    string Title;
    decimal ISBN13;
    string Contents;
    string Author;
    int PageCount;
}

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}


