﻿
/* ================= 예제 2.1: 기본 예제 파일 - Program.cs ================= */
// c:\temp 폴더에 Program.cs 파일명으로 저장

using System;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            // 문자열 출력
            Console.WriteLine("Hello World");
        }
    }
}