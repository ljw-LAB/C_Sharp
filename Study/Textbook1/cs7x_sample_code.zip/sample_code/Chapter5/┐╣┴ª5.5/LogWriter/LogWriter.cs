﻿using System;

public class LogWriter
{
    public void Write(string txt)
    {
        Console.WriteLine(txt);
    }
}