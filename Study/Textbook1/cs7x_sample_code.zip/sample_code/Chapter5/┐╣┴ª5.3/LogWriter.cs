﻿using System;

class LogWriter
{
    public void Write(string txt)
    {
        Console.WriteLine(txt);
    }
}