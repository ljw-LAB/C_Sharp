﻿
/* ================= 예제 5.3: Program.cs 파일의 내용 ================= */

using System;

class Program
{
    static void Main(string[] args)
    {
        LogWriter logWriter = new LogWriter();
        logWriter.Write("start");
    }
}
