﻿
/* ================= 예제 1.1: CIL 확인용 예제 ================= */

class Program
{
    static void Main(string[] args)
    {
        int a = 5;
        int b = 6;
        int c = a + b;
    }
}