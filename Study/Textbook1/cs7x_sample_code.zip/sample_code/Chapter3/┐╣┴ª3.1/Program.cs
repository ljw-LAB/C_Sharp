﻿
/* ================= 예제 3.1: 정수형 자료를 사용하는 코드 ================= */

using System;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            long sum;
        }
    }
}

